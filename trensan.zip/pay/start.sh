#!/bin/sh

tmux new-session -d -s p1 'sh 1.sh' &
tmux new-session -d -s p2 'sh 2.sh' &
tmux new-session -d -s p3 'sh 3.sh' &
tmux new-session -d -s p4 'sh 4.sh' &
tmux new-session -d -s p5 'sh 5.sh' &
tmux new-session -d -s p6 'sh 6.sh' &
tmux new-session -d -s p7 'sh 7.sh' &
tmux new-session -d -s p8 'sh 8.sh' &
tmux new-session -d -s p9 'sh 9.sh' &
tmux new-session -d -s p10 'sh 10.sh' &
tmux new-session -d -s p11 'sh 11.sh' &
tmux new-session -d -s p12 'sh 12.sh '
tmux new-session -d -s p13 'sh 13.sh' &
tmux new-session -d -s p14 'sh 14.sh' &
tmux new-session -d -s p15 'sh 15.sh' &
tmux new-session -d -s p16 'sh 16.sh' &
tmux new-session -d -s p17 'sh 17.sh' &
tmux new-session -d -s p18 'sh 18.sh' &
tmux new-session -d -s p19 'sh 19.sh' &
tmux new-session -d -s p20 'sh 20.sh' &
tmux new-session -d -s p21 'sh 21.sh' &
tmux new-session -d -s p22 'sh 22.sh' &
tmux new-session -d -s p23 'sh 23.sh' &
