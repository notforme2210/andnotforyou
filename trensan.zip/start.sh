#!/bin/sh
az group create --name myResourceGroup --location eastus

tmux new-session -d -s m1 'sh 1.sh' &
tmux new-session -d -s m2 'sh 2.sh' &
tmux new-session -d -s m3 'sh 3.sh' &
tmux new-session -d -s m4 'sh 4.sh' &
tmux new-session -d -s m5 'sh 5.sh' &
tmux new-session -d -s m6 'sh 6.sh' &
tmux new-session -d -s m7 'sh 7.sh' &
tmux new-session -d -s m8 'sh 8.sh' &
tmux new-session -d -s m9 'sh 9.sh' &
tmux new-session -d -s m10 'sh 10.sh' &
tmux new-session -d -s m11 'sh 11.sh' &
tmux new-session -d -s m12 'sh 12.sh '
tmux new-session -d -s m13 'sh 13.sh' &
tmux new-session -d -s m14 'sh 14.sh' &
tmux new-session -d -s m15 'sh 15.sh' &
tmux new-session -d -s m16 'sh 16.sh' &
tmux new-session -d -s m17 'sh 17.sh' &
tmux new-session -d -s m18 'sh 18.sh' &
tmux new-session -d -s m19 'sh 19.sh' &
tmux new-session -d -s m20 'sh 20.sh' &
tmux new-session -d -s m21 'sh 21.sh' &
tmux new-session -d -s m22 'sh 22.sh' &
tmux new-session -d -s m23 'sh 23.sh' &
